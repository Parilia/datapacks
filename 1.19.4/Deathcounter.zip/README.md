Run /function death_count:run_me_first
After that to get the menu back 
Run /function death_count:menu